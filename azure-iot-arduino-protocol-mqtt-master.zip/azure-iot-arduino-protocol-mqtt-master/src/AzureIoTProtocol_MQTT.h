// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef AZUREIOTPROTOCOLMQTT_H
#define AZUREIOTPROTOCOLMQTT_H

#include "azure_umqtt_c/mqtt_client.h"

#define AzureIoTProtocolMQTTVersion "1.0.45"

#endif //AZUREIOTPROTOCOLMQTT_H
